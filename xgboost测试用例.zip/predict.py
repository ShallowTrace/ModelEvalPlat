import pandas as pd
import xgboost as xgb
from pathlib import Path
import json

import csv
import os
from datetime import datetime
import random

# 创建目标目录（如果不存在）
output_path = "/app/prediction_result"

os.makedirs(output_path, exist_ok=True)

model_path="model.json"
test_data_path="/app/dataset/test_data.csv"

# 生成文件名
filename = f"result.csv"
filepath = os.path.join(output_path, filename)


def main():
    print("Starting prediction process...")


    try:
        # 1. 加载测试数据
        print(f"Loading test data from {test_data_path}")
        test_df = pd.read_csv(test_data_path)
        print(f"Loaded {len(test_df)} records with {len(test_df.columns)} features")

        # 2. 数据预处理 (必须与训练时保持一致)

        # 3. 加载预训练模型
        print(f"Loading model from {output_path}")
        model = xgb.Booster()
        model.load_model(model_path)

        # 4. 准备预测数据
        # 确保特征顺序与训练时一致
        dtest = xgb.DMatrix(test_df)

        # 5. 进行预测
        print("Generating predictions...")
        predictions = model.predict(dtest)
        risk_flags = (predictions > 0.5).astype(int)  # 二值化

        # 6. 保存结果
        result_df = pd.DataFrame({
            'risk_flag': risk_flags
        })

        print(f"Saving results to {filepath}")
        result_df.to_csv(filepath, index=False)

        print("Prediction completed successfully!")
        print(f"Predicted risk distribution:\n{result_df['risk_flag'].value_counts()}")

    except Exception as e:
        print(f"Prediction failed: {str(e)}")
        raise

if __name__ == "__main__":
    main()